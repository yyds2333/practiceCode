package org.nynd.service.roleService;

import org.nynd.pojo.Role;

import java.util.List;

public interface RoleService {
    //查询用户列表
    public List<Role> getRoleList();
}
