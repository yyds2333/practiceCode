package org.nynd.util;

public class Constants {
    public static final String USER_SESSION="userSession";
    public static final String MESSAGE="message";
}
